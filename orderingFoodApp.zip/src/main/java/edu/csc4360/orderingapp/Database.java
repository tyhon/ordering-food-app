package edu.csc4360.orderingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class Database extends SQLiteOpenHelper {

    public Database(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    private static final String DATABASE_NAME = "order.db";

    //user table
    private static final String USER_TABLE = "user_table";

    private static final String COL_USER_ID = "User_id";
    private static final String COL_USERNAME = "Username";
    private static final String COL_PASSWORD = "Password";

    //food table
    private static final String FOOD_TABLE = "food_table";

    private static final String COL_FOOD_ID = "Food_id";
    private static final String COL_FNAME = "Name";
    private static final String COL_CALORIES = "Calories";
    private static final String COL_FPRICE = "Price";

    //drink table
    private static final String DRINK_TABLE = "Dink_table";

    private static final String COL_DRINK_ID = "Drink_id";
    private static final String COL_DNAME = "Name";
    private static final String COL_DPRICE = "Price";

    //cart table
    private static final String CART_TABLE = "Cart_table";

    private static final String COL_CART_ID = "Cart_id";
    private static final String COL_CNAME = "Name";
    private static final String COL_CPRICE = "Price";

    SQLiteDatabase database;
    Context context;


    //create table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + USER_TABLE + " ( " + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_USERNAME + " TEXT unique not null, " + COL_PASSWORD + " TEXT)");
        db.execSQL("CREATE TABLE " + FOOD_TABLE + " ( " + COL_FOOD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_FNAME + " TEXT, " + COL_CALORIES + " INTEGER, " + COL_FPRICE + " INTEGER)");
        db.execSQL("CREATE TABLE " + DRINK_TABLE + " ( " + COL_DRINK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_DNAME + " TEXT, " + COL_DPRICE + " INTEGER)");
        db.execSQL("CREATE TABLE " + CART_TABLE + " ( " + COL_CART_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_CNAME + " TEXT, " + COL_CPRICE + " INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + FOOD_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DRINK_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + CART_TABLE);
        onCreate(db);
    }

    //Sign up
    public void signUp(String username, String password) {
        database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        database.insert(USER_TABLE, null, contentValues);
    }

    //check for username already exist
    public Cursor checkIfExist(String username) {
        database = getWritableDatabase();
        String query = "SELECT * FROM " + USER_TABLE + " WHERE " + COL_USERNAME + " = ?";
        Cursor result = database.rawQuery(query, new String[]{username});
        return result;
    }

    //sign in
    public Cursor signIn(String username, String password) {
        database = getWritableDatabase();
        String query = "SELECT * FROM " + USER_TABLE + " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?";
        Cursor result = database.rawQuery(query, new String[]{username, password});
        return result;
    }

    public Cursor getAllData() {
        database = getWritableDatabase();
        String query = "SELECT  * FROM " + USER_TABLE;
        Cursor result = database.rawQuery(query, null);
        return result;
    }

    public Cursor foodList() {
        database = getWritableDatabase();
        String query = "SELECT  * FROM " + FOOD_TABLE;
        Cursor result = database.rawQuery(query, null);
        return result;
    }

    public Cursor drinkList() {
        database = getWritableDatabase();
        String query = "SELECT  * FROM " + DRINK_TABLE;
        Cursor result = database.rawQuery(query, null);
        return result;
    }

    public Integer deleteUser(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(USER_TABLE, "Username = ?", new String[]{id});
    }

    public void updateUser(String uName, String uPass) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        //values.put(COL_USER_ID,id);
        values.put(COL_USERNAME, uName);
        values.put(COL_PASSWORD, uPass);


        db.update(USER_TABLE, values, "Username = ?", new String[]{uName});
    }
}
