package edu.csc4360.orderingapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> adapter;
    TextView txtTotalPrice;
    TextView txtUserName;
    private final int REQUEST_WRITE_CODE = 0;
    private Cart mCart;
    Button btnDownload;
    FoodAcivity food;
    DrinkActivity drink;
    //int total;

    ArrayList<String> cartFood;
    ArrayList<String> cartDrink;
    ArrayList<String> cart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        food = new FoodAcivity();
        drink = new DrinkActivity();
        cartFood = new ArrayList<String>();
        cartDrink = new ArrayList<String>();
        cart = new ArrayList<String>();
        cartFood = food.getFood();
        cartDrink = drink.getDrink();
        if(cartFood != null){
            cart.addAll(cartFood);
        }
        if (cartDrink != null){
            cart.addAll(cartDrink);
        }
        MainActivity.total = drink.getTotal()+food.getTotal();
        txtTotalPrice = (TextView)findViewById(R.id.txtTotal);
        txtTotalPrice.setText("Total your bill: $"+MainActivity.total);

        ListAdapter listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,cart);
        ListView listView = (ListView)findViewById(R.id.listViewAll);
        listView.setAdapter(listAdapter);
        mCart = new Cart(this);
        mCart.addItem("123");

        txtUserName = (TextView)findViewById(R.id.etxtUser);
        SharedPreferences mPrefs = getSharedPreferences("IDvalue", Context.MODE_PRIVATE);
        String vaule = mPrefs.getString("user","yea");
        txtUserName.setText(vaule);




    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_signout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_out:
                Intent intent2 = new Intent(this,MainActivity.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



}
