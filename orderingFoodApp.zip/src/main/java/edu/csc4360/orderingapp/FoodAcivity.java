package edu.csc4360.orderingapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class FoodAcivity extends AppCompatActivity {

    ListView listView;
    Database myDb;
    private static ArrayList<String> food;
    private static int totalFood;

    int[] images = {R.drawable.pho,
                    R.drawable.goicuon,
                    R.drawable.bunbohue,
                    R.drawable.bokho,
                    R.drawable.comchien,
                    R.drawable.ribeye,
                    R.drawable.grillshrimp,
                    R.drawable.grillchicken};
    String[] Name;
    String[] Price;

    //menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.cart:
                Intent intent = new Intent(this,CartActivity.class);
                startActivity(intent);
                return true;
            case R.id.signout:
                Intent intent2 = new Intent(this,MainActivity.class);
                startActivity(intent2);
                finishAffinity();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acivity_food);

        getSupportActionBar().setTitle("Food Menu");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView=findViewById(R.id.listViewFood);

        CustomAdaptor customAdaptor = new CustomAdaptor();
        listView.setAdapter(customAdaptor);

        myDb = new Database(this);

        Cursor cursor = myDb.foodList();
        Name=new String[8];
        int i = 0;
        while (cursor.moveToNext()){
            Name[i]=cursor.getString(1);
            i++;
        }

        Cursor cursor1 = myDb.foodList();
        Price=new String[8];
        int j = 0;
        while (cursor1.moveToNext()){
            Price[j]=cursor1.getString(3);
            j++;
        }
        food = new ArrayList<String>();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i==0) {
                    food.add(Name[0]);
                    food.add("$" + Price[0]);
                    totalFood = totalFood + Integer.parseInt(Price[0]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==1) {
                    food.add(Name[1]);
                    food.add("$" + Price[1]);
                    totalFood = totalFood + Integer.parseInt(Price[1]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }if (i==2) {
                    food.add(Name[2]);
                    food.add("$" + Price[2]);
                    totalFood = totalFood + Integer.parseInt(Price[2]);
                    Toast.makeText(getApplicationContext(),"Added to Cart", Toast.LENGTH_SHORT).show();
                }if (i==3) {
                    food.add(Name[3]);
                    food.add("$" + Price[3]);
                    totalFood = totalFood + Integer.parseInt(Price[3]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }if (i==4) {
                    food.add(Name[4]);
                    food.add("$" + Price[4]);
                    totalFood = totalFood + Integer.parseInt(Price[4]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==5) {
                    food.add(Name[5]);
                    food.add("$" + Price[5]);
                    totalFood = totalFood + Integer.parseInt(Price[5]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==6) {
                    food.add(Name[6]);
                    food.add("$" + Price[6]);
                    totalFood = totalFood + Integer.parseInt(Price[6]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==7) {
                    food.add(Name[7]);
                    food.add("$" + Price[7]);
                    totalFood = totalFood + Integer.parseInt(Price[7]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    public ArrayList<String> getFood(){
        return food;
    }
    public Integer getTotal(){return totalFood;};



    class CustomAdaptor extends BaseAdapter{

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup viewGroup) {
            LayoutInflater inflater = getLayoutInflater();
            convertView = inflater.inflate(R.layout.custom_layout, null);

            ImageView imageView = convertView.findViewById(R.id.imageView);
            TextView textViewN = convertView.findViewById(R.id.name);
            TextView textViewP = convertView.findViewById(R.id.price);

            imageView.setImageResource(images[i]);
            textViewN.setText(Name[i]);
            textViewP.setText("$"+Price[i]);

            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade);
            animation.setDuration(900);
            convertView.startAnimation(animation);
            return convertView;
        }
    }
}
