package edu.csc4360.orderingapp;

public class User {
    private String userId;
    private String username;
    private String pass;


    public User(String userId, String username, String pass) {
        this.userId = userId;
        this.username = username;
        this.pass = pass;
    }

    public User(String username, String pass) {
        this.username = username;
        this.pass = pass;
    }

    public User() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
