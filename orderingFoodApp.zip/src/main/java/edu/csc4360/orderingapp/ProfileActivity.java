package edu.csc4360.orderingapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {
    Database db;
    Button btnChangePass, btnDelete;
    TextView txtUserName;
    EditText etxtPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acticity_profile);

        db = new Database(this);
        txtUserName = (TextView)findViewById(R.id.etxtUser);
        SharedPreferences mPrefs = getSharedPreferences("IDvalue", Context.MODE_PRIVATE);
        String vaule = mPrefs.getString("user","yea");
        txtUserName.setText(vaule);
        etxtPass = (EditText)findViewById(R.id.newPass);
        btnChangePass = (Button)findViewById(R.id.btnChangePass);
        btnChangePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateUS();
            }
        });

        btnDelete = (Button)findViewById(R.id.btnDeleteAcc);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete();
                out();
            }
        });

    }

    public void out(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finishAffinity();
    }

    public  void updateUS(){


        String uName = txtUserName.getText().toString();
        String uPass = etxtPass.getText().toString();

        db.updateUser(uName,uPass);
    }

    public void delete(){
        String name = txtUserName.getText().toString();

        db.deleteUser(name);
    }
}
