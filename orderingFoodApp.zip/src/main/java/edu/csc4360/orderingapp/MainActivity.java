package edu.csc4360.orderingapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Database myDb;
    public static int total = 0;

    EditText username, password;
    Button signin, signup, viewbtn, map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb=new Database(this);

        username=(EditText)findViewById(R.id.usertext);
        password=(EditText)findViewById(R.id.passtext);

        signin=(Button)findViewById(R.id.signinbtn);
        SignIn();

        signup=(Button)findViewById(R.id.signupbtn);
        SignUp();


        /*map = (Button)findViewById(R.id.btnMap);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);

            }
        });*/
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_help:
                toLocation();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void toLocation() {
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }


    //sign in
    public void SignIn(){
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor result = myDb.signIn(username.getText().toString(),password.getText().toString());
                if(result.getCount()==0){
                    showMessage("SORRY","Username or Password is incorrect");
                    return;
                }
                while (result.moveToNext()){
                    SharedPreferences mPrefs = getSharedPreferences("IDvalue", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = mPrefs.edit();
                    editor.putString("user", username.getText().toString());
                    editor.apply();
                    openFood();
                }
            }
        });
    }

    public void openFood(){
        Intent intent = new Intent(this,MainMenuActivity.class);
        //intent.putExtra("user",username.getText().toString());
        startActivity(intent);
    }

    //sign up
    public void SignUp(){
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor check = myDb.checkIfExist(username.getText().toString());
                while(check.moveToNext()){
                        showMessage("OOPS", "Username already exists");
                }
                myDb.signUp(username.getText().toString(),
                        password.getText().toString());
            }
        });
    }

    public void viewAll(){
        viewbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor result = myDb.getAllData();
                if (result.getCount() == 0) {
                    //message
                    showMessage("Error","no data");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (result.moveToNext()){
                    buffer.append("userId :"+ result.getString(0)+"\n");
                    buffer.append("username :"+ result.getString(1)+"\n");
                    buffer.append("password :"+ result.getString(2)+"\n\n");;
                }
                showMessage("data",buffer.toString());
            }
        });
    }

    public void showMessage(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
