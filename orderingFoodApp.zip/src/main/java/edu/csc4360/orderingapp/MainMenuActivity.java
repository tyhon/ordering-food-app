package edu.csc4360.orderingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

public class MainMenuActivity extends AppCompatActivity {
    EditText user;
    Button btnFood, btnDrink;


    GestureDetectorCompat gesture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        gesture = new GestureDetectorCompat(this, new SwipeGesture());
        btnDrink = (Button)findViewById(R.id.drinkMenu);
        btnDrink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDrink();
            }
        });
        btnFood = (Button)findViewById(R.id.foodMenu);
        btnFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFood();
            }
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_profile:
                toProfile();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void toProfile(){
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.gesture.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    class SwipeGesture extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2,
                               float velocityX, float velocityY) {
            if (e2.getX()>e1.getX()){
                openFood();
            }
            else if (e2.getX()<e1.getX()){
                openDrink();
            }
            return true;
        }
    }

    public void openFood(){
        Intent intent = new Intent(this,FoodAcivity.class);
        startActivity(intent);
    }
    public void openDrink(){
        Intent intent = new Intent(this,DrinkActivity.class);
        startActivity(intent);
    }
}
