package edu.csc4360.orderingapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.telecom.Call;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import static android.widget.AdapterView.*;

public class DrinkActivity extends AppCompatActivity {

    ListView listView;
    Database myDb;
    EditText etxtUserName;
    public ArrayList<Details> drinkListC = new ArrayList<>();
    public ArrayAdapter<Details> adapter;
    Context context;
    private static ArrayList<String> drink;
    private static int totalDrink = 0;

    int[] images = {R.drawable.saurieng,
            R.drawable.bamau,
            R.drawable.bo,
            R.drawable.cafe,
            R.drawable.margarita,
            R.drawable.capuccino,
            R.drawable.hotchocolate};
    String[] Name;
    String[] Price;

    //menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.cart:
                Intent intent = new Intent(this,CartActivity.class);
                startActivity(intent);
                return true;
            case R.id.signout:
                Intent intent2 = new Intent(this,MainActivity.class);
                startActivity(intent2);
                finishAffinity();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);
        //etxtUserName = (EditText)findViewById(R.id.etxtUser);
        //etxtUserName.setText();

        getSupportActionBar().setTitle("Drink Menu");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView=findViewById(R.id.listViewDrink);

        CustomAdaptor customAdaptor = new CustomAdaptor();


        listView.setAdapter(customAdaptor);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(DrinkActivity.this, DetailActivity.class);

                Toast.makeText(context, drinkListC.get(position).getName(),Toast.LENGTH_SHORT).show();
                startActivity(intent);

                ;
            }
        });

        myDb = new Database(this);
        drinkListC.clear();
        Cursor cursor = myDb.drinkList();
        Name=new String[7];
        Price=new String[7];
        int i = 0;
        while (cursor.moveToNext()){
            Name[i]=cursor.getString(1);
            Price[i]=cursor.getString(2);
            Details dt = new Details();
            dt.setName(cursor.getString(1));
            dt.setPrice(cursor.getString(2));
            drinkListC.add(dt);

            i++;
        }
/*
        myDb = new Database(this);

        Cursor cursor = myDb.drinkList();
        Name=new String[7];
        int i = 0;
        while (cursor.moveToNext()){
            Name[i]=cursor.getString(1);
            i++;
        }

        Cursor cursor1 = myDb.drinkList();
        Price=new String[7];
        int j = 0;
        while (cursor1.moveToNext()) {
            Price[j] = cursor1.getString(2);
            j++;
        }*/
        drink = new ArrayList<String>();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i==0) {
                    drink.add(Name[0]);
                    drink.add("$" + Price[0]);
                    totalDrink = totalDrink + Integer.parseInt(Price[0]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==1) {
                    drink.add(Name[1]);
                    drink.add("$" +Price[1]);
                    totalDrink = totalDrink + Integer.parseInt(Price[1]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }if (i==2) {
                    drink.add(Name[2]);
                    drink.add("$" +Price[2]);
                    totalDrink = totalDrink + Integer.parseInt(Price[2]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }if (i==3) {
                    drink.add(Name[3]);
                    drink.add("$" +Price[3]);
                    totalDrink = totalDrink + Integer.parseInt(Price[3]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==4) {
                    drink.add(Name[4]);
                    drink.add("$" +Price[4]);
                    totalDrink = totalDrink + Integer.parseInt(Price[4]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==5) {
                    drink.add(Name[5]);
                    drink.add("$" +Price[5]);
                    totalDrink = totalDrink + Integer.parseInt(Price[5]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
                if (i==6) {
                    drink.add(Name[6]);
                    drink.add("$" +Price[6]);
                    totalDrink = totalDrink + Integer.parseInt(Price[6]);
                    Toast.makeText(getApplicationContext(),"Added to Cart",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public ArrayList<String> getDrink(){
        return drink;
    }
    public Integer getTotal(){
        return totalDrink;
    }

    class CustomAdaptor extends BaseAdapter{

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup viewGroup) {
            LayoutInflater inflater = getLayoutInflater();
            convertView = inflater.inflate(R.layout.customlayout, null);

            ImageView imageView = convertView.findViewById(R.id.imageView);
            TextView textViewN = convertView.findViewById(R.id.name);
            TextView textViewP = convertView.findViewById(R.id.price);

            imageView.setImageResource(images[i]);
            textViewN.setText(Name[i]);
            textViewP.setText("$"+Price[i]);

            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade);
            animation.setDuration(900);
            convertView.startAnimation(animation);
            return convertView;
        }
    }
}
